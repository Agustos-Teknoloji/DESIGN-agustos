import * as React from 'react';

/**
 * Editorial surface card — paper, hairline rule, generous radius. Restrained by
 * default; set `marked` for a leading 2px brand rule on featured cards.
 * Composes eyebrow + title + body.
 *
 * @startingPoint section="Content" subtitle="Editorial surface card" viewport="360x200"
 */
export interface CardProps {
  children?: React.ReactNode;
  /** Uppercase eyebrow above the title (H4). */
  eyebrow?: React.ReactNode;
  /** Card title (H2-scale). */
  title?: React.ReactNode;
  /** Leading 2px brand rule for featured/active cards. */
  marked?: boolean;
  as?: 'article' | 'div' | 'li' | 'a';
}

export function Card(props: CardProps): JSX.Element;
