import React from 'react';

/* Boxed action for lower-section CTAs and product UI. One size everywhere
   (44px min height, 6px radius, no shadow, no arrow — the arrow glyph is
   reserved for text links). Filled black is the committing action and never
   changes color on hover; outline is the real alternative and fills black
   with a white label on hover. 'brand' is a filled-RED variant reserved for
   the one approved exception: a dark-theme hero's primary CTA — never use it
   on a white/light surface. */

export function Button({
  children,
  variant = 'outline',   // 'primary' (ink fill) | 'brand' (red fill — dark-hero exception only) | 'outline' | 'ghost'
  as = 'button',
  href,
  style,
  ...rest
}) {
  const Tag = href ? 'a' : as;

  const base = {
    display: 'inline-flex', alignItems: 'center', gap: '0.5em',
    fontFamily: 'var(--display)', fontWeight: 600, fontSize: 15,
    lineHeight: 1, textDecoration: 'none', cursor: 'pointer',
    padding: '0.7em 1.1em', minHeight: 44, boxSizing: 'border-box',
    borderRadius: 'var(--radius-md)', border: '1px solid transparent',
    transition: 'background var(--dur) var(--ease), color var(--dur) var(--ease), border-color var(--dur) var(--ease)',
    background: 'transparent', color: 'var(--ink)',
  };
  const variants = {
    primary: { background: 'var(--ink)', color: 'var(--paper-white)', borderColor: 'var(--ink)' },
    brand:   { background: 'var(--red)', color: 'var(--white)', borderColor: 'var(--red)' },
    outline: { background: 'transparent', color: 'var(--ink)', borderColor: 'var(--ink)' },
    ghost:   { background: 'transparent', color: 'var(--ink-soft)', borderColor: 'transparent' },
  };

  return (
    <Tag
      className={`ds-btn ds-btn--${variant}`}
      href={href}
      style={{ ...base, ...variants[variant], ...style }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
