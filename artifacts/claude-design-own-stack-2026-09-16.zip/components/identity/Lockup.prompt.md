Persistent brand identity — the Laz Güneşi symbol plus a lowercase wordmark in one colour. Use in headers, footers, and document covers.

```jsx
<Lockup brand="agustos" size={24} href="/" />
```

Variants & props:
- `brand` — `"agustos"` (red — the only coloured mark) · `"pataraz"` · `"pld"` · `"iesdesk"` · `"specquick"` (all off-black). Colour is no longer a per-brand axis; only the publisher mark is red.
- `mono` — single-color (ink) expression for print/stamps.
- `name` — override the wordmark text (still rendered lowercase).
- `href` — makes it a quiet link (no underline, no hover decoration).

Rules: never add a subtitle or tagline; never give it a hover underline. The symbol sits in the mark's colour beside the wordmark so the two read as one unit.
