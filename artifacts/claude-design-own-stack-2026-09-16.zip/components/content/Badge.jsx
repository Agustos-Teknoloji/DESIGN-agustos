import React from 'react';

/* Small sentence-case label — meta, status, categories. Red is never a
   badge's own colour (it is not a content link or a menu item), so variants
   stay within the ink scale: neutral (hairline outline) and solid (ink
   fill). No uppercase, no wide tracking. */

export function Badge({
  children,
  variant = 'neutral',   // 'neutral' | 'solid'
  style,
  ...rest
}) {
  const variants = {
    neutral: { color: 'var(--ink-soft)', border: '1px solid var(--rule)', background: 'transparent' },
    solid:   { color: 'var(--paper-white)', border: '1px solid var(--ink)', background: 'var(--ink)' },
  };
  return (
    <span
      className={`ds-badge ds-badge--${variant}`}
      style={{
        display: 'inline-flex', alignItems: 'center',
        fontFamily: 'var(--display)', fontSize: 12.5, fontWeight: 600,
        textTransform: 'none', letterSpacing: 0,
        lineHeight: 1, padding: '0.45em 0.7em', borderRadius: 'var(--radius-sm)',
        whiteSpace: 'nowrap',
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
