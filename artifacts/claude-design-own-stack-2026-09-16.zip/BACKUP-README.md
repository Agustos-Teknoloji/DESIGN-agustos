# Claude Design project "Ağustos" — own stack, as retired on 2026-09-16

Verbatim copy of the Design project's hand-built layer at the moment it was retired in favour
of the pushed kit under `agustos-ui/`. Project ID `7fee69d5-01ee-4727-beaf-cb6c5bd923c4`.

- `SKILL.md`, `readme.md`, `styles.css`: the root files as they were before the rewrite.
- `tokens/*.css`, `_ds_bundle.js`: the shared runtime, copied from `screens/design/` in the
  repository (pulled verbatim 2026-09-15).
- `components/**`: the six React components with their `.d.ts` and `.prompt.md` files and the
  three component preview cards, fetched with `DesignSync get_file` on 2026-09-16.
- `cards/*.html`: the eighteen specimen cards, fetched the same way. Two of them
  (`brand-lockups.html`, `brand-symbol.html`) repeat one SVG block; the copies here were
  assembled from that block and match the remote markup.
- `_ds_manifest.json`: the Design app's compiled manifest at the same moment, for reference.

Why it was retired: these files restated the design rules on the Design side and had drifted
from the repository (arrows on hero links, sidebar as a free choice, 72ch measure, Google Fonts,
"Version 3.0"). Under the agreed sync policy the repository owns rules and the Design project
owns drawings. Decision record: `archive/MEMORY.md`, "Design's own stack retired (2026-09-16)".

To restore: write these files back with `DesignSync` after a `finalize_plan` that lists them.
