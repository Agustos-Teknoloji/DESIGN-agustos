import React from 'react';
import { LazGunesi } from './LazGunesi.jsx';

/* The publisher lockup: symbol + lowercase wordmark, both in brand color so
   the mark reads as one unit. Identity, not a link — quiet hover, no underline. */

const WORDMARKS = {
  agustos:   'ağustos',
  pataraz:   'pataraz',
  pld:       'pld türkiye',
  iesdesk:   'iesdesk',
  specquick: 'specquick',
};

export function Lockup({
  brand = 'agustos',
  name,
  size = 24,
  mono = false,
  as = 'span',
  href,
  style,
  ...rest
}) {
  const wordmark = name || WORDMARKS[brand] || brand;
  const Tag = href ? 'a' : as;
  const color = mono ? 'var(--ink)' : 'var(--brand)';

  return (
    <Tag
      className={`lockup brand-${brand}${mono ? ' lockup--mono' : ''}`}
      href={href}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.4em',
        fontSize: size,
        textDecoration: 'none',
        color,
        ...style,
      }}
      aria-label={wordmark}
      {...rest}
    >
      <span
        className="lockup__symbol"
        style={{
          width: '1.4em',
          height: '1.4em',
          flex: 'none',
          transform: 'translateY(0.08em)',
          color: 'inherit',
        }}
      >
        <LazGunesi size="100%" />
      </span>
      <span
        className="lockup__name"
        style={{
          fontFamily: 'var(--display)',
          fontWeight: 650,
          letterSpacing: 0,
          textTransform: 'lowercase',
          lineHeight: 1,
          color: 'inherit',
        }}
      >
        {wordmark}
      </span>
    </Tag>
  );
}
