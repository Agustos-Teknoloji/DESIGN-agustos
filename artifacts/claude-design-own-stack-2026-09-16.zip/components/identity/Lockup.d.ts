import * as React from 'react';

/**
 * The publisher lockup: Laz Güneşi symbol + lowercase wordmark, rendered as one
 * mark in the active brand color. Use it as the persistent identity in headers,
 * footers, and document covers. It is identity, not navigation — keep hover quiet.
 *
 * Only the publisher (Ağustos) mark is red; every other brand's mark is the
 * one off-black — colour is no longer a per-brand axis, name is.
 *
 * @startingPoint section="Identity" subtitle="Symbol + wordmark, per brand" viewport="320x120"
 */
export interface LockupProps {
  /** Which portfolio brand. Sets wordmark + color. Default "agustos". */
  brand?: 'agustos' | 'pataraz' | 'pld' | 'iesdesk' | 'specquick';
  /** Override the wordmark text. Defaults to the brand's canonical lowercase name. */
  name?: string;
  /** Font size in px (symbol scales from it). Default 24. */
  size?: number;
  /** Mono expression: symbol + wordmark in ink instead of brand color. */
  mono?: boolean;
  /** Render element when not a link. Default "span". */
  as?: 'span' | 'div' | 'h1';
  /** If set, renders as an <a> with quiet, no-underline hover. */
  href?: string;
}

export function Lockup(props: LockupProps): JSX.Element;
