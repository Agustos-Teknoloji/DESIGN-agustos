import * as React from 'react';

/**
 * The content link — one of exactly two places red is allowed: a permanent
 * 2px red rule, ink turning red on hover. Use inside prose and reading
 * matter. For navigation, use the plain-label treatment instead (see
 * base.css .plain-label) — red only reveals there on hover/current.
 *
 * @startingPoint section="Actions" subtitle="Content link · fixed red rule" viewport="360x80"
 */
export interface LinkProps {
  children: React.ReactNode;
  /** "primary" (ink) or "secondary" (ink-soft). Default "primary". */
  variant?: 'primary' | 'secondary';
  /** Append a trailing arrow (switches to display family for hero use). */
  arrow?: boolean;
  href?: string;
}

export function Link(props: LinkProps): JSX.Element;
