The Laz Güneşi symbol alone, tinting with currentColor.

```jsx
<span style={{ color: 'var(--brand)' }}><LazGunesi size={48} /></span>
```

Use for favicons, monograms, loaders, and negative tiles. For the full identity mark with wordmark, use `Lockup`.
