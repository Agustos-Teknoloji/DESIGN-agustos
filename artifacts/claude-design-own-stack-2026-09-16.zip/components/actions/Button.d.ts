import * as React from 'react';

/**
 * Boxed action for lower-section CTA rows and product UI where target size
 * matters. One size everywhere: 44px min height, 6px radius, no shadow, no
 * arrow. A CTA pair is always filled + outline — never two filled buttons.
 *
 * @startingPoint section="Actions" subtitle="Boxed CTA · primary / outline" viewport="360x120"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Fill style. Default "outline". "brand" is filled red — the one approved
   *  exception for a dark-theme hero's primary CTA. Never use "brand" on a
   *  light surface. */
  variant?: 'primary' | 'brand' | 'outline' | 'ghost';
  as?: 'button' | 'a';
  href?: string;
}

export function Button(props: ButtonProps): JSX.Element;
