Small sentence-case label — meta, status, category. No uppercase, no wide tracking.

```jsx
<Badge>Distribution</Badge>
<Badge variant="solid">New</Badge>
```

- `variant` — `"neutral"` (hairline) · `"solid"` (filled ink). Red is never a badge's own colour — it's reserved for content links and menu-hover rules, not status chips.
