import React from 'react';

/* Editorial surface card. White-on-white with a hairline rule, 10px radius,
   no shadow. Optional left rule (marked) uses ink, not red — red never
   decorates a card. */

export function Card({
  children,
  eyebrow,
  title,
  marked = false,        // adds a 2px ink rule on the leading edge
  as = 'article',
  style,
  ...rest
}) {
  const Tag = as;
  return (
    <Tag
      className={`ds-card${marked ? ' ds-card--marked' : ''}`}
      style={{
        background: 'var(--paper-white)',
        border: '1px solid var(--rule)',
        borderLeft: marked ? '2px solid var(--ink)' : '1px solid var(--rule)',
        borderRadius: 'var(--radius-lg)',
        padding: '24px 26px',
        ...style,
      }}
      {...rest}
    >
      {eyebrow && (
        <div className="type-h4" style={{ margin: 0 }}>
          {eyebrow}
        </div>
      )}
      {title && (
        <h3 className="type-h2" style={{ margin: eyebrow ? '0.6em 0 0' : 0, fontSize: 20 }}>
          {title}
        </h3>
      )}
      {children && (
        <div className="type-body" style={{ margin: (eyebrow || title) ? '0.6em 0 0' : 0, fontSize: 15 }}>
          {children}
        </div>
      )}
    </Tag>
  );
}
