# Ağustos Design System

**Version 3.0** · Type-first, multi-brand design system for Emre Güneş's brand portfolio.

Premium, clean, minimalistic, direct — B2B, addressed to architects and lighting designers. Scandinavian restraint with Mediterranean warmth, carried by the grays, the one cream band, and the copy — never decoration. This project is the **runnable** form of the locked v3 direction in `uploads/Color palette and design direction (1)/DESIGN-DECISIONS.md`.

---

## Scope of this project

This project has two separate parts.

- **This root layer** — this readme, plus `tokens/`, `cards/`, `components/`, and `ui_kits/` — is a hand-built design system. A person edits it directly in Claude Design. No automatic process updates it from the repository.
- **The `agustos-ui/` folder** holds the generated kit. The `DESIGN-agustos` GitHub repository builds this folder and pushes it here after each release, through the `/design-push` skill. Do not edit `agustos-ui/` by hand — a push overwrites it completely.

Check `agustos-ui/` first if you expect a repository change to appear here. This readme and the design system above it change only when a person edits them directly in Claude Design.

---

## What changed in v3

v3 supersedes the cream-substrate v2 direction. The headline changes:

- **White is the substrate**, not cream. Cream is retired to one full-bleed callout/CTA band (`.band-cream`) — it never fills a page.
- **Colour is no longer a per-brand axis.** Only the publisher (Ağustos) mark is red. Every other brand — Pataraz, PLD Türkiye, IESDesk, SpecQuick — is the one off-black. Brands now flex on **name alone**.
- **Red is fixed and rationed to exactly two places**: the rule under a content link, and the rule revealed under a menu item on hover/current (plus the keyboard focus ring). Never a fill, an icon, a stat, or a button on a light surface.
- **No uppercase anywhere.** Table headers, breadcrumbs, menu items, and the old "eyebrow" label are sentence case with normal tracking. No label above a headline — the headline carries the opening.
- **Four action tiers, no fifth**, one size (44px, no arrow on buttons).
- **A locked dark theme** — the same six colours, flipped roles, red unchanged.
- **Fluid layout, not breakpoints** — `clamp()` type, `flex-wrap` rows, a 1180px/32px-gutter content column.

## The portfolio

One publisher, five names. Every brand carries the same symbol and the same typography; only the publisher's mark is coloured.

| Brand | What it is | Mark colour | Wordmark |
|---|---|---|---|
| **Ağustos Teknoloji** | Lighting agency & distribution | `#cf142a` red | `ağustos` |
| **Pataraz** | Premium luminaire brand, mid-tier pricing | Off-black | `pataraz` |
| **PLD Türkiye** | Lighting publication archive | Off-black | `pld türkiye` |
| **IESDesk** | Software: batch IES/LDT validation | Off-black | `iesdesk` |
| **SpecQuick** | Software: generated spec sheets | Off-black | `specquick` |

Adding a brand is a name and one off-black variable — no new colour decision (~5 minutes).

---

## System philosophy

1. **Portability over preference.** Every decision must survive markdown → web → PDF → docx → plain text.
2. **The publisher precedes the brand.** Shared symbol + type say "from Emre's house" first; name identifies the publication — colour no longer does, except for the flagship.
3. **One symbol, forever.** The Laz Güneşi is the publisher's mark, carried by every brand.
4. **Red is a fixed signal, not a brand hue.** It is the same hex everywhere, restricted to content-link rules, menu-hover rules, and focus — never a surface fill, never a per-brand colour.
5. **White is the working substrate.** Cream is a rare, deliberate accent (one full-bleed band with hairline rules), not the paper.
6. **Turkish content declares its language.** Every Turkish block carries `lang="tr"`; CSS enables `font-feature-settings: "locl"` globally.

---

## Sources

- **`uploads/Color palette and design direction (1)/DESIGN-DECISIONS.md`** — the locked v3 specification. Source of truth for every value in this build.
- **`uploads/Color palette and design direction (1)/DESIGN.md`** — the expanded rationale, with links to the original `.dc.html` visual references (design references only — not copied verbatim; this project recreates them in this system's own stack).
- **`uploads/DESIGN.md`** — the earlier v2.1.2 canonical spec (cream substrate, per-brand colour). Superseded; kept for history.
- **GitHub: [`Agustos-Teknoloji/DESIGN-agustos`](https://github.com/Agustos-Teknoloji/DESIGN-agustos)** — the design-system repository (canonical `DESIGN.md`, decision history, `laz-gunesi-amblem/` symbol source). Browse it for the official symbol binaries and self-hosted font files.

> ⚠️ **Substitutions in this build** (replace when the repo is connected): fonts load from **Google Fonts** (Inter Tight, Inter, JetBrains Mono) instead of self-hosted `@fontsource` binaries — swap `tokens/fonts.css` once available. The Laz Güneşi symbol (`assets/laz-gunesi.svg`) is a parametric rebuild with path geometry extracted from the provided emblem PDF — no substitution needed.

---

## Content fundamentals

- **Voice: editorial, declarative, quiet.** Statements, not slogans. No eyebrow label above a headline — the headline carries the opening on its own.
- **Casing.** Sentence case everywhere — prose, headings, labels, table headers, breadcrumbs, menu items. No uppercase anywhere in v3. Wordmarks stay lowercase (`ağustos`).
- **Turkish.** First-class. Content blocks carry `lang="tr"`; diacritics render correctly.
- **CTA copy.** Sentence case, verb first: "Request pricing", not "Pricing request". Every standalone contact action reads "Contact" — the same word everywhere.
- **Numbers.** Tabular figures for tables and dashboards.

---

## Visual foundations

- **Substrate.** White is the paper (~70% of any surface). Cream (`#fdf5f5`) appears only as one full-bleed callout/CTA band with hairline rules top and bottom — never an inset card, never the whole page. Light gray (`#ebebeb`, `--surface`) is the functional-surface role: tiles, image regions, panels. An opt-in warm-dark layer (`[data-theme="dark"]`) flips paper/surface/callout-band/ink roles; red never adapts.
- **Colour.** Six colours, no seventh. Approximate proportion across a page: 70 white · 14 light gray · 8 black · 5 cream · 3 red. Red is a **fixed, universal signal** — not a per-brand hue — restricted to the content-link rule, the menu-hover/current rule, and the focus ring. Never a fill, an icon's own colour, a stat, or a button on a light surface (the one exception: a dark-theme hero's filled-red primary CTA).
- **Brand marks.** Only the Ağustos mark is red; every other brand is the one off-black. The multi-brand axis is name alone now.
- **Type.** Three families, one job each: **Inter Tight** (display — logotype, headlines at weight 300–400 with tight negative tracking, hero at 300, small sentence-case labels), **Inter** (body, 16.5–20px, 1.6 line height), **JetBrains Mono** (technical identifiers, tabular figures). No uppercase anywhere.
- **Spacing & rhythm.** Two distinct scales on purpose: in-content heading breaks (1em baseline / 2.5em section / 0.5em label exception) and page-level band spacing (64px, `--section-gap`). Layout column caps at 1180px with 32px gutters; body measure 72ch, hero deck 54ch.
- **Backgrounds.** Flat paper only. No gradients, textures, patterns, or decorative imagery.
- **Borders & rules.** Hairline separators (`#e8e4da`). The one "thick" line is the 2px red rule — content link, menu hover/current, and focus. That weight is reserved and meaningful.
- **Cards.** White, 1px hairline rule, 10px radius, no shadow. A featured card gets a leading 2px rule in **ink**, never red.
- **Radii.** Two only — 6px controls/small panels, 10px cards.
- **Shadows.** None in the editorial or product layer. Depth comes from rules and paper.
- **Animation.** 150ms, `cubic-bezier(0.2,0,0,1)`. Nothing scales, lifts, or glows.
- **Actions.** Four tiers, no fifth: filled black (committing, one per band), outline (the real alternative, fills black on hover), text + red rule (content link), plain label (navigation — red rule reveals only on hover/current). One size everywhere: 44px min height, 6px radius, no arrow on buttons. A CTA pair is always filled + outline.
- **Layout.** Fluid, not breakpoint-driven — `clamp()` for type, `flex-wrap` + `flex: 1 1 <basis>` for rows, never a fixed-column grid or a hard breakpoint. Spec sheets are the one fixed-size (A4) exception.

---

## Iconography

Deliberately icon-light — typographic, not iconographic. The only proprietary mark is the Laz Güneşi (`assets/laz-gunesi.svg`, `currentColor`). Arrows are the literal `→` glyph on `Link`/hero actions — never on `Button` (buttons carry no arrow in v3). No icon font, no icon sprite, no emoji.

---

## Index — what's in this project

**Foundations**
- `styles.css` — global entry point (`@import` lines only).
- `tokens/fonts.css` — webfont declarations.
- `tokens/colors.css` — the six colours, substrate roles, red as a fixed signal, the five brand marks, dark-theme flip.
- `tokens/typography.css` — type stacks + the 24 type tokens, no uppercase.
- `tokens/spacing.css` — in-content rhythm, page-layout tokens (1180/32/64), radii, motion.
- `tokens/base.css` — global element styles, `.plain-label`, layout primitives, action utilities.

**Components** (`window.AUstosDesignSystem_7fee69`)
- `components/identity/` — **LazGunesi**, **Lockup**
- `components/actions/` — **Link** (content link), **Button** (`primary`/`outline`/`ghost`/`brand`)
- `components/content/` — **Badge** (`neutral`/`solid`), **Card**

**Specimen cards** (`cards/`) — foundation cards across Type, Colors, Spacing, Brand, Actions. Rendered in the Design System tab.

**UI kits**
- `ui_kits/website/` — the Ağustos marketing site (white substrate, one cream band, sidebar or topbar nav, multi-brand). See its `README.md`.
- `ui_kits/iesdesk/` — the IESDesk product dashboard (white/dark, no brand hue, ink+gray accents). See its `README.md`.

**Assets**
- `assets/laz-gunesi.svg` — the symbol (`currentColor`).

**Skill**
- `SKILL.md` — Agent-Skill manifest for using this system in Claude Code.

---

## Using the system

Link `styles.css`, then either use the token classes directly (markdown/editorial surfaces) or mount the React components. Set a brand by adding a `brand-{slug}` class — everything inside resolves `var(--brand)`, which is red only for `agustos`. Dark theme is a `[data-theme="dark"]` attribute on `<html>` or any ancestor.

For the full locked v3 specification, read `uploads/Color palette and design direction (1)/DESIGN-DECISIONS.md`.
