The content link — one of exactly two places red is allowed. A permanent 2px red rule; ink at rest, ink turns red on hover.

```jsx
<Link href="/projects" arrow>See the work</Link>
<Link variant="secondary" href="/contact">Contact</Link>
```

- `variant` — `"primary"` (ink) or `"secondary"` (ink-soft).
- `arrow` — adds a trailing → and switches to the display family (for hero/nav actions).

Use this inside prose and hero rows — never for menu/nav items. Navigation is a plain label (`.plain-label` in `base.css`): no rule at rest, the red rule reveals only on hover or on the current item.
