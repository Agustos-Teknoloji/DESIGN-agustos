Boxed action for lower-section CTAs and product UI where a clear tap target matters.

```jsx
<Button variant="primary">Request pricing</Button>
<Button variant="outline">Download IES files</Button>
```

- `variant` — `"primary"` (ink fill) · `"outline"` · `"ghost"` · `"brand"` (filled red — reserved for the dark-theme hero's primary CTA, never a light surface).
- One size everywhere: 44px min height, 6px radius, no shadow, **no arrow** (arrows are a `Link`/text-action thing).
- A CTA pair is always filled + outline — never two filled buttons, never a plain label beside a filled button.
- Labels are sentence case, verb first: "Request pricing", not "Pricing request".

Prefer `Link` for hero and inline editorial actions; reach for `Button` when the surface needs a scannable, tappable control.
