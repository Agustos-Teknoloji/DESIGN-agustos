import React from 'react';

/* The content link — one of the two places red is allowed: a permanent 2px
   red rule. Ink at rest; ink turns red on hover, the rule stays put. Never
   use for navigation/menu items — those are plain labels (see base.css
   .plain-label), which show the red rule only on hover/current. */

export function Link({
  children,
  variant = 'primary',   // 'primary' (ink) | 'secondary' (ink-soft)
  arrow = false,
  href = '#',
  style,
  ...rest
}) {
  const color = variant === 'secondary' ? 'var(--ink-soft)' : 'var(--ink)';
  const weight = variant === 'secondary' ? 500 : 600;
  return (
    <a
      href={href}
      className={`ds-link ds-link--${variant}`}
      style={{
        color,
        fontWeight: weight,
        fontFamily: arrow ? 'var(--display)' : 'inherit',
        textDecoration: 'none',
        display: arrow ? 'inline-flex' : 'inline',
        alignItems: 'baseline',
        gap: '0.4em',
        backgroundImage: 'linear-gradient(var(--red), var(--red))',
        backgroundSize: '100% 2px',
        backgroundPosition: '0 calc(100% - 1px)',
        backgroundRepeat: 'no-repeat',
        paddingBottom: 3,
        transition: 'color var(--dur) var(--ease)',
        ...style,
      }}
      onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--red)'; rest.onMouseEnter && rest.onMouseEnter(e); }}
      onMouseLeave={(e) => { e.currentTarget.style.color = color; rest.onMouseLeave && rest.onMouseLeave(e); }}
      {...rest}
    >
      {children}
      {arrow && <span aria-hidden="true">→</span>}
    </a>
  );
}
