import * as React from 'react';

/**
 * The Laz Güneşi mark on its own — 18-blade rotational sun. Fills with
 * currentColor, so it inherits --brand or any color from context. Use for
 * favicons, monograms, loaders, and negative brand-color tiles.
 */
export interface LazGunesiProps {
  /** CSS size for width + height. Default "1em". */
  size?: string | number;
  /** Explicit fill. Omit to inherit currentColor (recommended). */
  color?: string;
  /** Accessible label. Default "Laz Güneşi". */
  title?: string;
  style?: React.CSSProperties;
}

export function LazGunesi(props: LazGunesiProps): JSX.Element;
