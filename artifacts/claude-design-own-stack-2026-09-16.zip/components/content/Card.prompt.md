Editorial surface card — white, hairline rule, 10px radius, no shadow.

```jsx
<Card eyebrow="Service" title="Lighting design" marked>
  Photometric studies, layouts, and on-site commissioning for architectural projects.
</Card>
```

- `eyebrow` — sentence-case label (the `.type-h4` small-label role — no uppercase).
- `title` — H2-scale heading.
- `marked` — leading 2px rule for featured/active cards, in **ink**, never red.
- `as` — element tag (`article` default; use `a` for a clickable card).

Keep cards quiet: no heavy shadows, no colored fills.
