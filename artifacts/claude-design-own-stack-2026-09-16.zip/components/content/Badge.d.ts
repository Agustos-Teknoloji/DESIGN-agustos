import * as React from 'react';

/**
 * Small sentence-case label — meta, status, category. No uppercase, no wide
 * tracking, no red: red is reserved for content links and menu-hover rules,
 * never a badge's own colour.
 *
 * @startingPoint section="Content" subtitle="Meta / status label" viewport="240x80"
 */
export interface BadgeProps {
  children: React.ReactNode;
  /** Default "neutral". */
  variant?: 'neutral' | 'solid';
}

export function Badge(props: BadgeProps): JSX.Element;
