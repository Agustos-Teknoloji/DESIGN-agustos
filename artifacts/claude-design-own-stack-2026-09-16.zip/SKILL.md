---
name: agustos-design-system
description: >-
  Build web pages, documents, and product UI for Emre Güneş's multi-brand
  lighting portfolio (Ağustos Teknoloji, Pataraz, PLD Türkiye, IESDesk,
  SpecQuick) using the Ağustos type-first design system (v3). Use whenever you
  are styling, writing, or laying out any surface for one of these brands,
  adding a new brand, or generating editorial/markdown content that must match
  the house. Covers the six-colour palette, the strict two-place red rule, the
  four action tiers, the type system, the Laz Güneşi symbol, the dark theme,
  and Turkish locale rules.
---

# Ağustos Design System (v3)

A type-first, multi-brand design system: one publisher, many publications. Every brand carries the same symbol and the same typography; brands flex on **name only now** — colour is fixed to the publisher (Ağustos is red; every other brand is one off-black). Premium, clean, minimalistic, direct — B2B, addressed to architects and lighting designers.

**Read `uploads/Color palette and design direction (1)/DESIGN-DECISIONS.md` first** — it is the locked v3 specification this build implements. This file is the quick operating manual.

## Setup

```html
<link rel="stylesheet" href="styles.css">
<!-- React 18.3.1 + Babel standalone (pinned), then: -->
<script src="_ds_bundle.js"></script>
```

```js
const { Lockup, Link, Button, Badge, Card } = window.AUstosDesignSystem_7fee69;
```

`styles.css` `@import`s the token layer: `tokens/fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `base.css`.

## The rules that changed in v3

1. **White is the substrate now.** Cream is retired to a full-bleed callout/CTA band (`.band-cream`) — it never fills a whole page again.
2. **Colour is no longer a per-brand axis.** Only the Ağustos mark is red (`#cf142a`). Every other brand — Pataraz, PLD Türkiye, IESDesk, SpecQuick — is the one off-black (`#15130f`). The axis is name, full stop.
3. **Red is fixed and rationed to exactly two places:** the 2px rule under a content link, and the 2px rule revealed under a menu item on hover/current (plus the keyboard focus ring). Never a red fill, a red icon, a red stat, or a red button on a light surface.
4. **No uppercase anywhere.** Labels, table headers, breadcrumbs, and menu items are sentence case with normal tracking. No eyebrow above a headline — the headline carries the opening.
5. **Four action tiers, no fifth:** filled black (committing), outline (real alternative), text + red rule (content link), plain label (navigation). One button size everywhere — 44px min height, no arrow on buttons.
6. **Fluid, not breakpoint-driven.** `clamp()` for type, `flex-wrap` + `flex: 1 1 <basis>` for rows — never a fixed-column grid or an `at 768px do X` breakpoint.

## Palette — six colours, locked

| Colour | Hex | Where |
|---|---|---|
| White | `#ffffff` | The substrate, ~70% of every surface |
| Cream | `#fdf5f5` | Full-bleed callout/CTA band only — never the paper |
| Light gray | `#ebebeb` | Functional surfaces: tiles, image regions, panels (`--surface`) |
| Dark gray | `#404040` | Secondary text (`--ink-soft`) |
| Off-black | `#15130f` | Headlines, filled buttons, footer (`--ink`) |
| Red | `#cf142a` | Fixed signal — never a per-brand hue (`--red`) |

Support: hairline rule `#e8e4da`, faint label `#8a8378`.

## Dark theme — same six colours, flipped, opt-in

`[data-theme="dark"]` (on `<html>` or any ancestor) flips paper→off-black, surface→dark gray, callout-band→light-gray, ink→white, ink-soft→faint-label. **Red never adapts.** The one approved deviation: a dark hero's primary CTA is filled red (`Button variant="brand"`) since black-on-dark isn't available as the commit colour — never use that variant on a light surface.

## Brand axis — name only

| Slug | Wordmark | Mark colour |
|---|---|---|
| `agustos` | ağustos | Red — the only coloured mark |
| `pataraz` | pataraz | Off-black |
| `pld` | pld türkiye | Off-black |
| `iesdesk` | iesdesk | Off-black |
| `specquick` | specquick | Off-black |

**Add a brand (~5 min):** add `--brand-{slug}: var(--off-black);` + `.brand-{slug}{--brand:var(--brand-{slug})}` to `tokens/colors.css`, then a wordmark wherever brands are mapped. No new typography, logo, colour decision, or structure.

## Actions — four tiers

`Button variant="primary"` (filled black) · `variant="outline"` (fills black, white label on hover) · `Link` (content link, fixed red rule, ink→red on hover) · `.plain-label` (nav/breadcrumb/footer — red rule reveals only on hover/current). A CTA pair is always filled + outline. Labels are sentence case, verb first: "Request pricing", not "Pricing request".

## Type — three families, no uppercase

**Inter Tight** (display — headlines at weight 300–400, tight negative tracking, hero at 300) · **Inter** (body, 16.5–20px, 1.6 line height) · **JetBrains Mono** (technical data, tabular figures). `.type-h4` is now a sentence-case small label (table headers, breadcrumbs, meta) — not an uppercase eyebrow.

## Layout

Content column max **1180px**, **32px** gutters (`var(--container-max)`, `var(--container-gutter)`). Body measure 72ch, hero deck 54ch. Compact rhythm: **64px** between page-level bands (`var(--section-gap)`), 2.5em/1em/0.5em for in-content heading breaks — two different scales, kept distinct on purpose. Spec sheets are the one fixed-size (A4) exception; everything else is fluid.

## Components

`Lockup`, `LazGunesi`, `Link` (content link), `Button` (`primary`/`outline`/`ghost`/`brand`), `Badge` (`neutral`/`solid` — no red), `Card` (`marked` rule is ink, never red). Props documented in each `.d.ts` and `.prompt.md`.

## Worked surfaces

- `ui_kits/website/` — the editorial marketing site (white substrate, one cream band, sidebar or topbar nav).
- `ui_kits/iesdesk/` — the IESDesk product dashboard (white/dark, ink+gray accents, no brand hue).
- `cards/` — specimen cards across Type, Colors, Spacing, Brand, Actions.

## Before calling a change done

1. No page-wide cream; cream only inside a full-bleed band with hairline rules top/bottom.
2. Red appears only on content-link rules, menu-hover/current rules, and focus rings — never a fill, icon, stat, or button on a light surface.
3. No uppercase in labels/headers/menus. No eyebrow above a headline.
4. Buttons are 44px, no arrow; a CTA pair is filled + outline.
5. Turkish uppercase is correct with `lang="tr"` (`ışık` → `IŞIK`).
6. No raw color or font literals introduced — only tokens and `.type-*`.
